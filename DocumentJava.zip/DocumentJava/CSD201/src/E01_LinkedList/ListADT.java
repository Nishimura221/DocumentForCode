/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package E01_LinkedList;

/**
 *
 * @author DELL
 */
public interface ListADT<E> {
    void add(E element);
    boolean isEmpty();
}
