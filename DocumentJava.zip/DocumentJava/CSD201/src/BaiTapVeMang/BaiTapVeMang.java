/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BaiTapVeMang;

import java.util.Scanner;
import java.util.Random;

/**
 *
 * @author DELL
 */
public class BaiTapVeMang {

    float a[];
    int n;

    public BaiTapVeMang() {
        System.out.println("Nhap vao so luong phan tu cua mang: ");
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        a = taoMangSoThuc(n);
        printA();
    }

    public void printA() {
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");

        }

    }

    public float[] taoMangSoThuc(int n) {
        Random r = new Random();
        float[] temp = new float[n];
        for (int i = 0; i < n; i++) {
            temp[i] = r.nextFloat();
        }
        return temp;
    }

    public static void main(String[] args) {
        BaiTapVeMang b = new BaiTapVeMang();

    }
}
