/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package E07_BinaryTree;

/**
 *
 * @author DELL
 */
public class ArrayQueue implements QueueADT {

    private Object[] a;
    private int max;
    private int first, last;
  
    public ArrayQueue() {
        this(10);
    }

    public ArrayQueue(int max) {
        this.max = max;
        a= new Object[max];
        first= last=-1;
    }

    
    
    @Override
    public void clear() {
       a=new Object[max];
       first = last =-1;
    }

    @Override
    public boolean isEmpty() {
       return(first ==-1 && last ==-1);
    }

    @Override
    public void enqueue(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object dequeue() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object front() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int size() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

    


}
