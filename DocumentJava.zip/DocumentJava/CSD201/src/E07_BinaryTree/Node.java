/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package E07_BinaryTree;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Node {

    private Object info;
    private Node left, right;

    public Node() {
    }

    public Node(Object info) {
        this.info = info;
        this.left = null;
        this.right = null;

    }

    public Node(Node left, Node right) {
        this.left = left;
        this.right = right;
    }

    public Object getInfo() {
        return info;
    }

    public void setInfo(Object info) {
        this.info = info;
    }

    public Node getLeft() {
        return left;
    }

    public void setLeft(Node left) {
        this.left = left;
    }

    public Node getRight() {
        return right;
    }

    public void setRight(Node right) {
        this.right = right;
    }

    public void visit(Node p) {
        System.out.println(p.info + " ");
    }

    public void breadth() {
        Node root = this;
        if (root == null) {
            return;
        }
        
        
    }
}
