/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package slot6;

/**
 *
 * @author DELL
 */
public class DecToBin {
        public static void decToBin(int n){
         int q = n/2;
         int r= n%2;
         if(n==0){
          return;
         
         }
        else
             decToBin(q);
            System.out.print(r);
        }
        public static void main(String[] args){
        
            System.out.print("12 => Bin : ");
            decToBin(12);
        
        }
}
