/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package slot6;

/**
 *
 * @author DELL
 */
public class IndirectRecursionExample {

    public static void print(int n) {
        if (n % 2 == 0) {
            printEven(n);
        } else {
            printOdd(n);

        }

    }

    public static void printOdd(int n) {
        if (n <= 0) {
            return;
        }
        System.out.println("Số lẻ: " + n);

    }

    public static void printEven(int n) {
        if (n <= 0) {
            return;
        }
        System.out.println("Số chẵn: " + n);
        printOdd(n - 1);

    }

    public static void main(String[] args) {
        int n = 25;
        print(25);

    }
}
