/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package E09_heap;

/**
 *
 * @author DELL
 */
public class Heap {

    public static void buildMaxHeap(int[] arr, int n) {
        for (int i = 1; i < n; i++) {
            int x = arr[i];
            int son = i;
            while (son > 0 && x > arr[(son - 1) / 2]) {
                arr[son] = arr[(son - 1) / 2];
                son = (son - 1) / 2;
            }
            arr[son] = x;
        }
    }

    public static void heapToSortedArray(int[] arr, int n) {
        for (int i = n - 1; i > 0; i--) {
            int x = arr[i];
            arr[i] = arr[0];

            int father = 0;
            int son = 2 * father + 1;
            if (son + 1 < i && arr[son] < arr[son + 1]) {
                son = son + 1;
            }
            while (son < i && x < arr[son]) {
                arr[father] = arr[son];
                father = son;
                son = 2 * father + 1;
                if (son + 1 < i && arr[son] < arr[son + 1]) {
                    son = son + 1;
                }
            }
            arr[father] = x;
        }

    }
}
