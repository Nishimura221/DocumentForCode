/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BSTree;

/**
 *
 * @author DELL
 */
public class Node {
        int info;
    Node left, right;

    Node(int x, Node l, Node r) {
        info = x;
        left = l;
        right = r;
    }

    Node(int x) {
        this(x, null, null);
    }

}
