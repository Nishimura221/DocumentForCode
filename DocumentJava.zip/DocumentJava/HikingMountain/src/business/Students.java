/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import model.Student;
import tools.Acceptable;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.StatisticalInfo;

public class Students {

    private List<Student> students;
    public Mountains mountainManager;

    public Students(Mountains mountainManager) {
        this.students = new ArrayList<>();
        this.mountainManager = mountainManager;
    }

    public boolean isStudentIdExists(String id) {
        for (Student s : students) {
            if (s.getId().equalsIgnoreCase(id)) {
                return true;
            }

        }
        return false;
    }

    public boolean addStudent(Student student) {
        if (!mountainManager.isValidMountainCode(student.getMountainCode())) {
            System.out.println("Invalid mountain code. Registration failed.");
            return false;
        }
        students.add(student);
        return true;
    }

    public boolean updateStudent(String id, String name, String phone, String email, String mountainCode) {
        for (Student student : students) {
            if (student.getId().equalsIgnoreCase(id)) {
                if (!mountainCode.isEmpty() && !mountainManager.isValidMountainCode(mountainCode)) {
                    System.out.println("Invalid mountain code. Update failed for mountain code.");
                    return false;
                }
                if (!name.isEmpty()) {
                    student.setName(name);
                }
                if (!phone.isEmpty() && Acceptable.isValid(phone, Acceptable.PHONE_PATTERN)) {
                    student.setPhone(phone);
                }
                if (!email.isEmpty() && Acceptable.isValid(email, Acceptable.EMAIL_PATTERN)) {
                    student.setEmail(email);
                }
                if (!mountainCode.isEmpty()) {
                    student.setMountainCode(mountainCode);
                }
                double tuitionFee = 6000000;
            
                if (Acceptable.isValid(phone, Acceptable.VIETTEL_PATTERN) || Acceptable.isValid(phone, Acceptable.VNPT_PATTERN)) {
                    tuitionFee *= 0.65;
                    student.setTuitionFee(tuitionFee);
                }
                else if(!phone.isEmpty() && Acceptable.isValid(phone, Acceptable.PHONE_PATTERN)){
                     student.setTuitionFee(tuitionFee); 
                }
                return true;
            }
        }
        return false;
    }

    public void displayAll() {
        if (students.isEmpty()) {
            System.out.println("No students have registered yet.");
        } else {
            String header = String.format("| %-10s | %-20s | %-15s | %-10s | %-12s |",
                    "Student ID", "Name", "Phone",  "Peak Code", "Fee");
            String line = "+------------+----------------------+-----------------+------------+--------------+";
            System.out.println(line);
            System.out.println(header);
            System.out.println(line);

            for (Student student : students) {
                System.out.printf("| %-10s | %-20s | %-15s | %-10s | %,12.2f |\n",
                        student.getId(),
                        student.getName(),
                        student.getPhone(),
                        student.getMountainCode(),
                        student.getTuitionFee());
            }
            System.out.println(line);

        }
    }

    public boolean deleteStudent(String id) {
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getId().equalsIgnoreCase(id)) {
                students.remove(i);
                return true;
            }
        }
        return false;
    }

    public List<Student> searchById(String id) {
        List<Student> result = new ArrayList<>();
        for (Student student : students) {
            if (student.getId().equalsIgnoreCase(id)) {
                result.add(student);
            }
        }
        return result;
    }

    public void searchStudentByName(String name) {
        List<Student> result = new ArrayList<>();
        for (Student student : students) {
            if (student.getName().toLowerCase().contains(name.toLowerCase())) {
                result.add(student);
            }
        }

        if (result.isEmpty()) {
            System.out.println("No participants match the search criteria.");
        } else {
            String header = String.format("| %-10s | %-20s | %-15s | %-30s | %-10s | %-12s |",
                    "Student ID", "Name", "Phone", "Email", "Peak Code", "Fee");
            String line = "+------------+----------------------+-----------------+--------------------------------+------------+--------------+";
            System.out.println(line);
            System.out.println(header);
            System.out.println(line);

            for (Student student : result) {
                System.out.printf("| %-10s | %-20s | %-15s | %-30s | %-10s | %,12.2f |\n",
                        student.getId(),
                        student.getName(),
                        student.getPhone(),
                        student.getEmail(),
                        student.getMountainCode(),
                        student.getTuitionFee());
            }
            System.out.println(line);
        }
    }

    public void filterByCampus(String campusCode) {
        List<Student> filtered = new ArrayList<>();
        for (Student student : students) {
            if (student.getId().startsWith(campusCode.toUpperCase())) {
                filtered.add(student);
            }
        }

        if (filtered.isEmpty()) {
            System.out.println("No participants registered under this campus.");
        } else {
            String header = String.format("| %-10s | %-20s | %-15s | %-30s | %-10s | %-12s |",
                    "Student ID", "Name", "Phone", "Email", "Peak Code", "Fee");
            String line = "+------------+----------------------+-----------------+--------------------------------+------------+--------------+";
            System.out.println(line);
            System.out.println(header);
            System.out.println(line);

            for (Student student : filtered) {
                System.out.printf("| %-10s | %-20s | %-15s | %-30s | %-10s | %,12.2f |\n",
                        student.getId(),
                        student.getName(),
                        student.getPhone(),
                        student.getEmail(),
                        student.getMountainCode(),
                        student.getTuitionFee());
            }
            System.out.println(line);
        }
    }

    public void displayStatistics() {
        if (students.isEmpty()) {
            System.out.println("No data for statistics.");
            return;
        }

        Map<String, StatisticalInfo> statsMap = new HashMap<>();

        for (Student student : students) {
            String mountainCode = student.getMountainCode();
            double tuitionFee = student.getTuitionFee();

            if (!statsMap.containsKey(mountainCode)) {
                statsMap.put(mountainCode, new StatisticalInfo(mountainCode, 0, 0.0));
            }

            StatisticalInfo info = statsMap.get(mountainCode);
            info.setNumOfStudents(info.getNumOfStudents() + 1);
            info.setTotalCost(info.getTotalCost() + tuitionFee);
        }

        String header = String.format("| %-13s | %-12s | %-15s |", "Mountain Code", "Participants", "Total Fee");
        String line = "+---------------+--------------+-----------------+";
        System.out.println(line);
        System.out.println(header);
        System.out.println(line);

        for (StatisticalInfo info : statsMap.values()) {
            System.out.printf("| %-13s | %-12d | %,15.2f |\n",
                    info.getMountainCode(),
                    info.getNumOfStudents(),
                    info.getTotalCost());
        }
        System.out.println(line);
    }

    public void saveToFile(String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(students);
            System.out.println("Data has been saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }

    public void loadFromFile(String filename) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            students = (List<Student>) ois.readObject();
            System.out.println("Data has been loaded successfully.");
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filename);
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found: " + e.getMessage());
        }
    }
}
