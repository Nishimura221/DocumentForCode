    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import model.Mountain;
import java.util.List;
import java.io.*;
import java.util.ArrayList;

public class Mountains {

    private List<Mountain> mountains;

    public Mountains() {
        this.mountains = new ArrayList<>();
    }

    public void loadFromCSV(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 4) {
                    String peakCode = generatePeakCode(Integer.parseInt(data[0].trim()));
                    mountains.add(new Mountain(peakCode, data[1].trim(), data[2].trim(), data[3].trim()));

                }

            }
            System.out.println("Mountains have been loaded successfully.");

        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filename);

        } catch (IOException | NumberFormatException e) {
            System.out.println("Error reading file: " + e.getMessage());

        }

    }

    public boolean isValidMountainCode(String code) {
        for (Mountain mountain : mountains) {

            if (mountain.getCode().equalsIgnoreCase(code)) {
                return true;
            }
        }
        return false;
    }

    public void displayAll() {
        if (mountains.isEmpty()) {
            System.out.println("No mountains available.");
        } else {
            System.out.println("Mountain List:");
            for (Mountain mountain : mountains) {
                System.out.println(mountain);
            }
        }

    }

    public static String generatePeakCode(int number) {
        return String.format("MT%02d", number);

    }

}
