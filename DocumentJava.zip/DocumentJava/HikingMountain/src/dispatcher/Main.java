/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dispatcher;

import business.Mountains;
import business.Students;
import tools.Inputter;
import tools.Acceptable;
import model.Student;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        Mountains mountainManager = new Mountains();
        Students studentManager = new Students(mountainManager);

        String dataFile = "src\\business\\students.dat";
        String mountainFile = "src\\business\\MountainList.csv";

        try {
            mountainManager.loadFromCSV(mountainFile);
            System.out.println("Mountain data loaded successfully.");
        } catch (Exception e) {
            System.out.println("Error loading mountain data: " + e.getMessage());
        }

        try {
            studentManager.loadFromFile(dataFile);
            System.out.println("Student data loaded successfully.");
        } catch (Exception e) {
            System.out.println("Error loading student data: " + e.getMessage());
        }

        while (true) {
            printMenu();
            int choice = Inputter.getInt("Enter your choice: ");
            switch (choice) {
                case 1:
                    addStudent(studentManager);
                    break;
                case 2:
                    updateStudent(studentManager);
                    break;
                case 3:
                    studentManager.displayAll();
                    break;
                case 4:
                    deleteStudent(studentManager);
                    break;
                case 5:
                    searchStudentByName(studentManager);
                    break;
                case 6:
                    filterByCampus(studentManager);
                    break;
                case 7:
                    displayStatistics(studentManager);
                    break;
                case 8:
                    saveDataToFile(studentManager, dataFile);
                    break;
                case 9:
                    exitProgram(studentManager, dataFile);
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n***********************************************");
        System.out.println("*                                             *");
        System.out.println("*  Mountain Hiking Challenge Registration     *");
        System.out.println("*                 Main Menu                   *");
        System.out.println("*                                             *");
        System.out.println("***********************************************");
        System.out.println("* 1. New Registration                         *");
        System.out.println("* 2. Update Registration Information          *");
        System.out.println("* 3. Display Registered List                  *");
        System.out.println("* 4. Delete Registration Information          *");
        System.out.println("* 5. Search Participants by Name              *");
        System.out.println("* 6. Filter Data by Campus                    *");
        System.out.println("* 7. Statistics of Registration by Location   *");
        System.out.println("* 8. Save Data to File                        *");
        System.out.println("* 9. Exit Program                             *");
        System.out.println("***********************************************");
        System.out.println("* Please enter your choice (1-9):             *");
        System.out.println("***********************************************");
    }

    private static void addStudent(Students studentManager) {
        System.out.println("\n--- New Registration ---");
        String id;
        while (true) {
            id = Inputter.getCode("Enter student ID (e.g., SE123456): ", Acceptable.STUDENT_ID_PATTERN);
            if (!studentManager.isStudentIdExists(id)) {
                break;
            }
            System.out.println("Student id has exist!!!");
            return;
        }

        String name = Inputter.getString("Enter name: ", Acceptable.NAME_PATTERN);
        String phone = Inputter.getString("Enter phone number: ", Acceptable.PHONE_PATTERN);
        String email = Inputter.getString("Enter email: ", Acceptable.EMAIL_PATTERN);

        String mountainCode;
        while (true) {
            mountainCode = Inputter.getCode("Enter mountain code(e.g., MT01 - MT13): ", Acceptable.MOUNTAIN_CODE_PATTERN);
            if (studentManager.mountainManager.isValidMountainCode(mountainCode)) {
                break;
            }
            System.out.println("Invalid mountain code. Please enter a valid code from the list.");
        }

        double tuitionFee = 6000000;
        if (Acceptable.isValid(phone, Acceptable.VIETTEL_PATTERN) || Acceptable.isValid(phone, Acceptable.VNPT_PATTERN)) {
            tuitionFee *= 0.65;
        }

        Student student = new Student(id, name, phone, email, mountainCode, tuitionFee);
        studentManager.addStudent(student);
        System.out.println("Student registered successfully.");
    }

    private static void updateStudent(Students studentManager) {
        System.out.println("\n--- Update Registration Information ---");

        while (true) {
            String id = Inputter.getString("Enter student ID to update information(SE******): ", Acceptable.STUDENT_ID_PATTERN);

            List<Student> students = studentManager.searchById(id);

            if (students.isEmpty()) {
                System.out.println("This student has not registered yet.");
                return;
            } else {
                Student student = students.get(0);
                System.out.println("Student Details:");
                System.out.println("-----------------------------------------------------");
                System.out.println("Student ID: " + student.getId());
                System.out.println("Name       : " + student.getName());
                System.out.println("Phone      : " + student.getPhone());
                System.out.println("Email      : " + student.getEmail());
                System.out.println("Mountain   : " + student.getMountainCode());
                System.out.printf("Fee        : %,.2f\n", student.getTuitionFee());
                System.out.println("-----------------------------------------------------");
                String confirmation = Inputter.getString("Are you sure you want to update this registration??(Y/N)", "^[YyNn]$");
                if (confirmation.equalsIgnoreCase("N")) {
                    System.out.println("The update has been canceled");
                    return;
                } else {
                    String name = Inputter.getString("Enter new name (leave empty to keep current): ", "^.*$");
                    String phone = Inputter.getString("Enter new phone (leave empty to keep current): ", "^.*$");
                    String email = Inputter.getString("Enter new email (leave empty to keep current): ", "^.*$");
                    String mountainCode = Inputter.getString("Enter new mountain code (leave empty to keep current): ", "^.*$");

                    studentManager.updateStudent(id, name, phone, email, mountainCode);
                    System.out.println("Student information updated successfully.");
                    return;
                }
            }
        }
    }

    private static void deleteStudent(Students studentManager) {
        System.out.println("\n--- Delete Registration Information ---");
        String id = Inputter.getString("Enter student ID to delete(SE******): ", Acceptable.STUDENT_ID_PATTERN);

        List<Student> students = studentManager.searchById(id);

        if (students.isEmpty()) {
            System.out.println("This student has not registered yet.");
        } else {
            Student student = students.get(0);
            System.out.println("Student Details:");
            System.out.println("-----------------------------------------------------");
            System.out.println("Student ID: " + student.getId());
            System.out.println("Name       : " + student.getName());
            System.out.println("Phone      : " + student.getPhone());
            System.out.println("Email      : " + student.getEmail());
            System.out.println("Mountain   : " + student.getMountainCode());
            System.out.printf("Fee        : %,.2f\n", student.getTuitionFee());
            System.out.println("-----------------------------------------------------");

            String confirmation = Inputter.getString("Are you sure you want to delete this registration? (Y/N): ", "^[YyNn]$");
            if (confirmation.equalsIgnoreCase("Y")) {
                if (studentManager.deleteStudent(id)) {
                    System.out.println("The registration has been successfully deleted.");
                } else {
                    System.out.println("An error occurred while deleting the registration.");
                }
            } else {
                System.out.println("The deletion has been canceled.");
            }
        }
    }

    private static void searchStudentByName(Students studentManager) {
        System.out.println("\n--- Search Participants by Name ---");
        String name = Inputter.getString("Enter name or partial name: ", ".*");
        studentManager.searchStudentByName(name);
    }

    private static void filterByCampus(Students studentManager) {
        System.out.println("\n--- Filter Data by Campus ---");
        String campusCode = Inputter.getString("Enter campus code (HE, SE, CE, DE, QE): ", "^(HE|SE|CE|DE|QE)$");
        studentManager.filterByCampus(campusCode);
    }

    private static void displayStatistics(Students studentManager) {
        System.out.println("\n--- Statistics of Registration Numbers by Location ---");
        studentManager.displayStatistics();
    }

    private static void saveDataToFile(Students studentManager, String dataFile) {
        System.out.println("\n--- Save Data to File ---");
        studentManager.saveToFile(dataFile);
    }

    private static void exitProgram(Students studentManager, String dataFile) {
        System.out.println("\n--- Exit Program ---");
        String saveChanges = Inputter.getString("Do you want to save changes before exiting? (Y/N): ", "^[YyNn]$");
        if (saveChanges.equalsIgnoreCase("Y")) {
            studentManager.saveToFile(dataFile);
        }
        System.out.println("Exiting the program. Goodbye!");
    }

}
