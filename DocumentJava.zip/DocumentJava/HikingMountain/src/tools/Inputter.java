/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

import java.util.Scanner;

public class Inputter {

    private static final Scanner scanner = new Scanner(System.in);

    public static String getString(String mess, String pattern) {
        while (true) {
            System.out.println(mess);
            String input = scanner.nextLine().trim();
            if (Acceptable.isValid(input, pattern)) {
                return input;

            }
            System.out.println("Dữ liệu không hợp lệ. Vui lòng nhập lại!");
        }
    }

    public static int getInt(String mess) {
        while (true) {
            try {
                System.out.print(mess);
                return Integer.parseInt(scanner.nextLine().trim());

            } catch (NumberFormatException e) {
                System.out.println("Dữ liệu không hợp lệ. Vui lòng nhập số nguyên!");
            }

        }

    }

    public static double getDouble(String mess) {
        while (true) {
            try {
                System.out.println(mess);
                return Double.parseDouble(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Dữ liệu không hợp lệ. Vui lòng nhập số thực!");
            }

        }

    }
    public static String getCode(String mess, String pattern) {
        while (true) {
            System.out.println(mess);
            String input = scanner.nextLine().trim();
            if (Acceptable.isValid(input, pattern)) {
                return input.substring(0,2).toUpperCase()+input.substring(2);

            }
            System.out.println("Dữ liệu không hợp lệ. Vui lòng nhập lại!");
        }
    }

    public static String inputAndLoop(String mess, String pattern) {
        return getString(mess, pattern);
    }
}
