/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

import java.util.regex.Pattern;

/**
 *
 * @author DELL
 */
public interface Acceptable {

    public final String STUDENT_ID_PATTERN = "^[CcDdHhSsQq][Ee]\\d{6}$";
    public final String NAME_PATTERN = "^.{2,20}$";
    public final String PHONE_PATTERN = "^0\\d{9}$";
    public final String EMAIL_PATTERN = "^[\\w.%+-]+@[\\w.-]+\\.[a-zA-Z]{2,6}$";
    public final String MOUNTAIN_CODE_PATTERN = "^[A-Za-z0-9]+$";
    public final String VIETTEL_PATTERN = "^(032|033|034|035|036|037|038|039|086|096|097|098)\\d{7}$";
    public final String VNPT_PATTERN = "^(081|082|083|084|085|088|091|094)\\d{7}$";

    static boolean isValid(String data, String pattern) {

        return Pattern.matches(pattern, data);
    }
}
