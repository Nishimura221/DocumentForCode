/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package democode;

import java.util.Random;
import java.util.Scanner;

public class BaiTapVeMang {

    float a[];
    int n;

    public BaiTapVeMang() {
        System.out.println("Nhập vào số lượng phần tử của mảng:");
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        a = taoMangSoThuc(n);
        printA();

    }

    public void printA() {
        for (int i = 0; i < a.length; i++) {
            System.out.println(a[i] + " ");
        }

    }

    public float[] taoMangSoThuc(int n) {
        Random r = new Random();
        float[] temp = new float[n];
        for (int i = 0; i < n; i++) {

            temp[i] = r.nextFloat();
        }
        return temp;
    }

    public void addX(float x) {
        n = n + 1;
        float[] temp = new float[n];
        for (int i = 0; i < a.length; i++) {
            temp[i] = a[i];

        }
        temp[n-1]=x;
        a=temp; 
        
    }

    public static void main(String[] args) {
        BaiTapVeMang b = new BaiTapVeMang();
        b.addX(1.5f);
        System.out.println();
        b.printA();
    }

}
