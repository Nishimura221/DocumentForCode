/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LinkedList01;

/**
 *
 * @author DELL
 */
import LinkedList01.Node;

public class SinglyLinkedList {

    Node head; //1->2->3 

    public void addLast(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;

        }
        //tim Node cuoi cung
        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;

        }
        //temp chinh thuc la node cuoi cung hien tai
        temp.next = newNode;
        //lay node cuoi cung hien tai noi voi newNode

    }

    public void deleteFirst() {
        if (head == null) {
            System.out.println("Danh sách rỗng !!!");
            return;
                    
        }
        head = head.next;

    }
    public void display(){
     if(head==null){
         System.out.println("Danh sách rỗng!!!");
         
      return;
     }
     Node temp=head;
        System.out.println("Linked list: ");
        while(temp!=null){
            System.out.println(temp.getData()+" -> ");
            temp=temp.next;
        }
        System.out.println("null");
    }
   
}
