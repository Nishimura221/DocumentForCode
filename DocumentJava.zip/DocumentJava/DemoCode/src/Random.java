/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.*;
public class Random {
    public static void main(String[] args) {
    String fullName = "Nguyễn Văn A"; // Họ và tên đầy đủ

        // Tìm vị trí dấu cách cuối cùng
        int lastSpace = fullName.lastIndexOf(" ");

        // Nếu không có dấu cách, tức là chỉ có một từ (giữ nguyên)
        if (lastSpace == -1) {
            System.out.println(fullName);
            return;
        }

        // Lấy phần tên (từ cuối cùng)
        String lastName = fullName.substring(lastSpace + 1);

        // Lấy phần họ và tên đệm (tất cả trước dấu cách cuối cùng)
        String firstAndMiddle = fullName.substring(0, lastSpace);

        // Kết quả: "Tên, Họ và tên đệm"
        System.out.println(lastName + ", " + firstAndMiddle);
    }
}
