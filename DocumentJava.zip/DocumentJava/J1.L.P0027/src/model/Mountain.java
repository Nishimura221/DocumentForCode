/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

public class Mountain implements Serializable {
    private String code;         // Mountain Code
    private String name;         // Mountain Name
    private String province;     // Province Name
    private String description;  // Description of the Mountain

    public Mountain(String code, String name, String province, String description) {
        this.code = code;
        this.name = name;
        this.province = province;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return String.format("%s | %s | %s | %s", code, name, province, description);
    }
}
