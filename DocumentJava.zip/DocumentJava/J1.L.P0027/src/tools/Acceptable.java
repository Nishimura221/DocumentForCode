 
package tools;

import java.util.regex.Pattern;

/**
 * Interface chứa các hằng số và phương thức static để kiểm tra dữ liệu đầu vào.
 */
public interface Acceptable {
    // Mẫu kiểm tra dữ liệu
    String STUDENT_ID_PATTERN = "^[CcDdHhSsQq][Ee]\\d{6}$"; // Mã sinh viên
    String NAME_PATTERN = "^.{2,20}$";                      // Tên sinh viên
    String PHONE_PATTERN = "^0\\d{9}$";                    // Số điện thoại
    String EMAIL_PATTERN = "^[\\w.%+-]+@[\\w.-]+\\.[a-zA-Z]{2,6}$"; // Email
    String MOUNTAIN_CODE_PATTERN = "^[A-Za-z0-9]+$"; 
    String VIETTEL_PATTERN = "^(03|07|08|09|01[2|6|8|9])\\d{7}$";  // Số của Viettel
    String VNPT_PATTERN = "^(081|082|083|084|085|088|091|094)\\d{7}$"; // Số của VNPT
    

    /**
     * Phương thức kiểm tra chuỗi dựa trên mẫu.
     *
     * @param data Chuỗi dữ liệu cần kiểm tra
     * @param pattern Mẫu dữ liệu
     * @return true nếu dữ liệu khớp, ngược lại false
     */
    static boolean isValid(String data, String pattern) {
        return Pattern.matches(pattern, data);
    }
}
