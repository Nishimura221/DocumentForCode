/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

import java.util.Scanner;

/**
 * Lớp hỗ trợ nhập dữ liệu và kiểm tra tính hợp lệ.
 */
public class Inputter {
    private static final Scanner scanner = new Scanner(System.in);

    /**
     * Nhập chuỗi và kiểm tra tính hợp lệ.
     *
     * @param message Thông báo nhập liệu
     * @param pattern Mẫu kiểm tra
     * @return Chuỗi hợp lệ
     */
    public static String getString(String message, String pattern) {
        while (true) {
            System.out.print(message);
            String input = scanner.nextLine().trim();
            if (Acceptable.isValid(input, pattern)) {
                return input;
            }
            System.out.println("Dữ liệu không hợp lệ. Vui lòng nhập lại!");
        }
    }

    /**
     * Nhập một số nguyên.
     *
     * @param message Thông báo nhập liệu
     * @return Số nguyên hợp lệ
     */
    public static int getInt(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Dữ liệu không hợp lệ. Vui lòng nhập số nguyên!");
            }
        }
    }

    /**
     * Nhập một số thực.
     *
     * @param message Thông báo nhập liệu
     * @return Số thực hợp lệ
     */
    public static double getDouble(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Double.parseDouble(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Dữ liệu không hợp lệ. Vui lòng nhập số thực!");
            }
        }
    }

    /**
     * Nhập dữ liệu và kiểm tra tính hợp lệ theo vòng lặp.
     *
     * @param message Thông báo nhập liệu
     * @param pattern Mẫu kiểm tra
     * @return Chuỗi hợp lệ
     */
    public static String inputAndLoop(String message, String pattern) {
        return getString(message, pattern);
    }
}
