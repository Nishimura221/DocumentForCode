/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import model.Student;
import tools.Acceptable;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.StatisticalInfo;

/**
 * Lớp quản lý danh sách sinh viên và các chức năng liên quan.
 */
public class Students {

    private List<Student> students;
    public Mountains mountainManager;

    public Students(Mountains mountainManager) {
        this.students = new ArrayList<>();
        this.mountainManager = mountainManager;
    }

    /**
     * Kiểm tra xem ID sinh viên đã tồn tại trong hệ thống hay chưa.
     *
     * @param id Mã sinh viên
     * @return true nếu tồn tại, ngược lại false
     */
    public boolean isStudentIdExists(String id) {
        for (Student s : students) {
            if (s.getId().equalsIgnoreCase(id)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Chức năng 1: Thêm sinh viên mới.
     *
     * @param student Đối tượng Student
     * @return true nếu thêm thành công, ngược lại false
     */
    public boolean addStudent(Student student) {
        if (!mountainManager.isValidMountainCode(student.getMountainCode())) {
            System.out.println("Invalid mountain code. Registration failed.");
            return false;
        }
        students.add(student);
        return true;
    }

    /**
     * Chức năng 2: Cập nhật thông tin sinh viên.
     *
     * @param id Mã sinh viên
     * @param name Tên mới
     * @param phone Số điện thoại mới
     * @param email Email mới
     * @param mountainCode Mã núi mới
     * @return true nếu cập nhật thành công, ngược lại false
     */
    public boolean updateStudent(String id, String name, String phone, String email, String mountainCode) {
        for (Student student : students) {
            if (student.getId().equalsIgnoreCase(id)) {
                if (!mountainCode.isEmpty() && !mountainManager.isValidMountainCode(mountainCode)) {
                    System.out.println("Invalid mountain code. Update failed for mountain code.");
                    return false;
                }

                if (!name.isEmpty()) {
                    student.setName(name);
                }
                if (!phone.isEmpty() && Acceptable.isValid(phone, Acceptable.PHONE_PATTERN)) {
                    student.setPhone(phone);
                }
                if (!email.isEmpty() && Acceptable.isValid(email, Acceptable.EMAIL_PATTERN)) {
                    student.setEmail(email);
                }
                if (!mountainCode.isEmpty()) {
                    student.setMountainCode(mountainCode);
                }
                return true;
            }
        }
        return false; // Không tìm thấy sinh viên
    }

    /**
     * Chức năng 3: Hiển thị danh sách sinh viên.
     */
    public void displayAll() {
        if (students.isEmpty()) {
            System.out.println("No students have registered yet.");
        } else {
            String header = String.format("| %-10s | %-20s | %-15s | %-30s | %-10s | %-12s |",
                    "Student ID", "Name", "Phone", "Email", "Peak Code", "Fee");
            String line = "+------------+----------------------+-----------------+--------------------------------+------------+--------------+";
            System.out.println(line);
            System.out.println(header);
            System.out.println(line);

            for (Student student : students) {
                System.out.printf("| %-10s | %-20s | %-15s | %-30s | %-10s | %,12.2f |\n",
                        student.getId(),
                        student.getName(),
                        student.getPhone(),
                        student.getEmail(),
                        student.getMountainCode(),
                        student.getTuitionFee());
            }
            System.out.println(line);
        }
    }

    /**
     * Chức năng 4: Xóa sinh viên khỏi danh sách.
     *
     * @param id Mã sinh viên
     * @return true nếu xóa thành công, ngược lại false
     */
    public boolean deleteStudent(String id) {
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getId().equalsIgnoreCase(id)) {
                students.remove(i);
                return true;
            }
        }
        return false;
    }

    /**
     * Method tìm sinh viên theo ID.
     *
     * @param id Mã sinh viên cần tìm.
     * @return Danh sách sinh viên khớp với ID (thường chỉ có 1 sinh viên).
     */
    public List<Student> searchById(String id) {
        List<Student> result = new ArrayList<>();
        for (Student student : students) {
            if (student.getId().equalsIgnoreCase(id)) {
                result.add(student);
            }
        }
        return result;
    }

    /**
     * Chức năng 5: Tìm sinh viên theo tên.
     *
     * @param name Tên sinh viên
     * @return Danh sách sinh viên khớp
     */
    public void searchStudentByName(String name) {
        List<Student> result = new ArrayList<>();
        for (Student student : students) {
            if (student.getName().toLowerCase().contains(name.toLowerCase())) {
                result.add(student);
            }
        }

        if (result.isEmpty()) {
            System.out.println("No participants match the search criteria.");
        } else {
            String header = String.format("| %-10s | %-20s | %-15s | %-30s | %-10s | %-12s |",
                    "Student ID", "Name", "Phone", "Email", "Peak Code", "Fee");
            String line = "+------------+----------------------+-----------------+--------------------------------+------------+--------------+";
            System.out.println(line);
            System.out.println(header);
            System.out.println(line);

            for (Student student : result) {
                System.out.printf("| %-10s | %-20s | %-15s | %-30s | %-10s | %,12.2f |\n",
                        student.getId(),
                        student.getName(),
                        student.getPhone(),
                        student.getEmail(),
                        student.getMountainCode(),
                        student.getTuitionFee());
            }
            System.out.println(line);
        }
    }

    /**
     * Chức năng 6: Lọc sinh viên theo mã cơ sở.
     *
     * @param campusCode Mã cơ sở (HE, SE, ...)
     * @return Danh sách sinh viên thuộc cơ sở
     */
    public void filterByCampus(String campusCode) {
        List<Student> filtered = new ArrayList<>();
        for (Student student : students) {
            if (student.getId().startsWith(campusCode.toUpperCase())) {
                filtered.add(student);
            }
        }

        if (filtered.isEmpty()) {
            System.out.println("No participants registered under this campus.");
        } else {
            String header = String.format("| %-10s | %-20s | %-15s | %-30s | %-10s | %-12s |",
                    "Student ID", "Name", "Phone", "Email", "Peak Code", "Fee");
            String line = "+------------+----------------------+-----------------+--------------------------------+------------+--------------+";
            System.out.println(line);
            System.out.println(header);
            System.out.println(line);

            for (Student student : filtered) {
                System.out.printf("| %-10s | %-20s | %-15s | %-30s | %-10s | %,12.2f |\n",
                        student.getId(),
                        student.getName(),
                        student.getPhone(),
                        student.getEmail(),
                        student.getMountainCode(),
                        student.getTuitionFee());
            }
            System.out.println(line);
        }
    }

    /**
     * Chức năng 7: Tạo thống kê số lượng sinh viên theo mã núi.
     *
     * @return Danh sách thống kê
     */
    public void displayStatistics() {
        if (students.isEmpty()) {
            System.out.println("No data for statistics.");
            return;
        }

        // Sử dụng HashMap để thống kê
        Map<String, StatisticalInfo> statsMap = new HashMap<>();

        for (Student student : students) {
            String mountainCode = student.getMountainCode();
            double tuitionFee = student.getTuitionFee();

            // Nếu chưa có mã núi trong bản đồ, tạo mới
            if (!statsMap.containsKey(mountainCode)) {
                statsMap.put(mountainCode, new StatisticalInfo(mountainCode, 0, 0.0));
            }

            // Cập nhật thông tin thống kê
            StatisticalInfo info = statsMap.get(mountainCode);
            info.setNumOfStudents(info.getNumOfStudents() + 1);
            info.setTotalCost(info.getTotalCost() + tuitionFee);
        }

        // Hiển thị kết quả thống kê dưới dạng bảng
        String header = String.format("| %-13s | %-12s | %-15s |", "Mountain Code", "Participants", "Total Fee");
        String line = "+---------------+--------------+-----------------+";
        System.out.println(line);
        System.out.println(header);
        System.out.println(line);

        for (StatisticalInfo info : statsMap.values()) {
            System.out.printf("| %-13s | %-12d | %,15.2f |\n",
                    info.getMountainCode(),
                    info.getNumOfStudents(),
                    info.getTotalCost());
        }
        System.out.println(line);
    }

    /**
     * Chức năng 8: Ghi danh sách sinh viên vào file.
     *
     * @param filename Tên file
     */
    public void saveToFile(String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(students);
            System.out.println("Data has been saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }

    /**
     * Chức năng 9: Đọc danh sách sinh viên từ file.
     *
     * @param filename Tên file
     */
    public void loadFromFile(String filename) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            students = (List<Student>) ois.readObject();
            System.out.println("Data has been loaded successfully.");
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filename);
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found: " + e.getMessage());
        }
    }
}
