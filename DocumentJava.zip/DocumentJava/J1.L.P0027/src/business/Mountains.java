package business;

import model.Mountain;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Lớp quản lý danh sách núi.
 */
public class Mountains {
    private List<Mountain> mountains;

    public Mountains() {
        this.mountains = new ArrayList<>();
    }

    /**
     * Tải danh sách núi từ file CSV.
     *
     * @param filename Tên file CSV
     */
    public void loadFromCSV(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            // Bỏ qua dòng tiêu đề
            br.readLine();

            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 4) {
                    String peakCode = generatePeakCode(Integer.parseInt(data[0].trim()));
                    mountains.add(new Mountain(peakCode, data[1].trim(), data[2].trim(), data[3].trim()));
                }
            }
            System.out.println("Mountains have been loaded successfully.");
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filename);
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }

    /**
     * Kiểm tra mã núi có hợp lệ không.
     *
     * @param code Mã núi cần kiểm tra
     * @return true nếu mã hợp lệ, false nếu không
     */
    public boolean isValidMountainCode(String code) {
        for (Mountain mountain : mountains) {
            if (mountain.getCode().equalsIgnoreCase(code)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Hiển thị danh sách núi.
     */
    public void displayAll() {
        if (mountains.isEmpty()) {
            System.out.println("No mountains available.");
        } else {
            System.out.println("Mountain List:");
            for (Mountain mountain : mountains) {
                System.out.println(mountain);
            }
        }
    }

    /**
     * Phương thức tạo mã Peak Code theo định dạng MTxx
     * @param number Số đầu vào
     * @return Mã Peak Code với tiền tố "MT"
     */
    public static String generatePeakCode(int number) {
        return String.format("MT%02d", number);
    }
}