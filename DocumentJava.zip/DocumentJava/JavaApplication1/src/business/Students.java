/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.List;
import model.Student;
import java.util.ArrayList;
import java.util.Scanner;
import tools.Inputter;
import java.text.DecimalFormat;

/**
 *
 * @author DELL
 */
public class Students {

    private static boolean isSaved = false;
    public static ArrayList<Student> students = new ArrayList<>();

    public static void addNewStudent() {
        String id = Inputter.getStudentID();
        String name = Inputter.inputName();
        String phoneNumber = Inputter.inputPhoneNumber();
        String email = Inputter.inputEmail();
        String mountainCode = Inputter.mountainCode();
        String tuitionFee = Double.toString(Inputter.tuitionFee(phoneNumber));
        Student student = new Student(id, name, phoneNumber, email, mountainCode, tuitionFee);
        students.add(student);
        isSaved = false;
    }

    public static Student searchById(String id) {
        for (Student student : students) {
            if (student.getId().equalsIgnoreCase(id)) {
                return student;
            }

        }
        return null;
    }

    public static void update() {
        Scanner sc = new Scanner(System.in);
        Student student;
        while (true) {
            System.out.println("Enter ID of the student to update: ");
            String findStudentID = sc.nextLine();
            student = searchById(findStudentID);
            if (student != null) {
                student = searchById(findStudentID);
                System.out.println("Enter new information to update or press 'ENTER' to skip.");
                break;
            } else {
                System.out.println("Student not found, TRY AGAIN!");

            }

        }
        while (true) {
            System.out.println("Enter new name: ");
            String newName = sc.nextLine();
            if (newName.isEmpty()) {
                System.out.println("No change! Keeping current name.");
                break;
            } else if (Inputter.isValid(newName, tools.Acceptable.NAME_VALID)) {
                student.setName(newName);
                System.out.println("New name has been updated.");
                break;
            } else {
                System.out.println("Invalid name! TRY AGAIN.");
            }

        }
        while (true) {
            System.out.println("Enter new phone number: ");
            String newPhone = sc.nextLine();
            if (newPhone.isEmpty()) {
                System.out.println("No change! Keeping current phone number.");
                break;
            } else if (Inputter.isValid(newPhone, tools.Acceptable.PHONE_VALID)) {
                student.setPhone(newPhone);
                System.out.println("New phone number has been updated. ");
                break;
            } else {
                System.out.println("Invalid phone number! TRY AGAIN.");
            }
        }

        while (true) {
            System.out.println("Enter new email: ");
            String newEmail = sc.nextLine();
            if (newEmail.isEmpty()) {
                System.out.println("No change! Keeping current email.");
                break;
            } else if (Inputter.isValid(newEmail, tools.Acceptable.EMAIL_VALID)) {
                student.setEmail(newEmail);
                System.out.println("New email has been updated.");
                break;

            } else {
                System.out.println("Invalid email! TRY AGAIN.");
            }

        }
        while (true) {
            System.out.println("Enter new mountain code: ");
            String newMountain = sc.nextLine();
            if (newMountain.isEmpty()) {
                System.out.println("No change! Keeping current mountain code.");

            } else if (Mountains.isValidMountainCode(newMountain)) {
                student.setMountainCode("MT" + newMountain);
                System.out.println("New mountain code has been updated.");
                break;
            } else {
                System.out.println("Invalid mountain code! TRY AGAIN.");
            }

        }
        isSaved = false;
        System.out.println("Successfully updated!!");
    }

    public static void delete() {
        String answer;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter student ID to delete: ");
        String findStudentID = sc.nextLine();
        Student student = searchById(findStudentID);
        if (student != null) {
            showMessage(student);
            System.out.println("Are you sure you want to be delete this registration? (Y/N)");
            answer = sc.nextLine();
            if (answer.equalsIgnoreCase("Y")) {
                students.remove(student);
                isSaved = false;
                System.out.println("The registration has been successfully deleted.");

            } else {

                System.out.println("The deletion process is cancelled.");
            }

        } else {
            System.out.println("This student has not registered yet.");
        }

    }

   public static void searchByName() {
        ArrayList<Student> searchedName = new ArrayList<>();
        System.out.println("Enter name to search: ");
        String name = Inputter.inputName().toLowerCase();
        for (Student student : students) {
            if (student.getName().toLowerCase().contains(name)) {
                searchedName.add(student);
            }
        }
        if(searchedName.isEmpty()){
            System.out.println("No one matches the search criteria!");
        }
        else{
            System.out.println("Matching Students:");
            showAll(searchedName);
            
        }

    }
   public static void showAll(ArrayList<Student> students) {
        if (students.isEmpty()) {
            System.out.println("No students have registered yet.");
        } else {
            System.out.println("---------------------------------------------------------------------------------");
            System.out.println("| Student ID  | Name               | Phone        | Mountain Code | Tuition Fee |");
            System.out.println("---------------------------------------------------------------------------------");
            for (Student student : students) {
                String fee = formatTuitionFee(Inputter.tuitionFee(student.getPhone()));
                student.setTuitionFee(fee);
                System.out.println(student);
            }
            System.out.println("---------------------------------------------------------------------------------");
        }
    }
      public static String formatTuitionFee(double tuitionFee) {
        DecimalFormat decimalFormat = new DecimalFormat("#,###");
        String finalTuitionFee = decimalFormat.format(tuitionFee);
        return finalTuitionFee;
    }
    public static void showMessage(Student student) {
        System.out.println("Student Details:");
        System.out.println("--------------------------------------------------");
        System.out.println("Student ID: " + student.getId());
        System.out.println("Name      : " + student.getName());
        System.out.println("Phone     : " + student.getPhone());
        System.out.println("Mountain  : " + student.getMountainCode());
        System.out.println("Fee       : " + student.getTuitionFee());
        System.out.println("--------------------------------------------------");

    }

    public static void showCurrent(Student student) {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("| Student ID  | Name               | Phone        | Mountain Code | Tuition Fee |");
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println(student);
        System.out.println("---------------------------------------------------------------------------------");
    }
}
