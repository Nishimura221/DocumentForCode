/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

/**
 *
 * @author DELL
 */
public interface Acceptable {
    public static final String STUDENT_ID_VALID="^[CcDdHhSsQq] [Ee]\\d{6}$";
    public static final String NAME_VALID="^.{2,20}$";
    public static final String DOUBLE_VALID="^\\d+(\\.\\d+)?$";
    public static final String INTEGER_VALID="\\d+";
    public static final String PHONE_VALID="\\d{10}";
    public static final String VIETTEL_VALID="^(086|096|097|098|03[2-9])\\d{7}$";
    public static final String VNPT_VALID="^(081|082|083|084|085|088|091|094)\\d{7}$";
    public static final String EMAIL_VALID="^[a-zA-Z0-9+.%-]+@[a-zA-Z0-9.-]+\\\\.[a-zA-Z]{2,}$";
    public static boolean isValid(String data, String pattern){
    
      return data.matches(pattern);
      
    }
    
}
