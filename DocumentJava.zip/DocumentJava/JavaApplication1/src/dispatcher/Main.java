/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dispatcher;
import java.util.Scanner;
/**
 *
 * @author DELL
 */
public class Main {
    public static void Menu(){
        System.out.println("1. New Registration");
        System.out.println("2. Update Registration Information");
        System.out.println("3. Display Registered List");
        System.out.println("4. Delete Registration Information");
        System.out.println("5. Search Participants by Name");
        System.out.println("6. Filter Data by Campus");
        System.out.println("7. Statistics of Registration Numbers by Location");
        System.out.println("8. Save Data to File");
        System.out.println("9. Exit the Program");
    }
    public static void main(String[] args){
        int choice;
       try{ 
        do{
         Menu();
         System.out.println("Enter your choice: ");
         Scanner sc= new Scanner(System.in);
        
         choice= sc.nextInt();
         switch(choice){
             case 1:System.out.println("Running"); break;
             case 2: break;
             case 3: break;
             case 4: break;
             case 5: break;
             case 6: break;
             case 7: break;
             case 8: break;
             case 9: System.out.println("Program exiting..."); break;
    
         }
        }while(choice>9||choice<=8);
       }catch(Exception e){
             do{
         Menu();
         System.out.println("Enter your choice: ");
         Scanner sc= new Scanner(System.in);
        
         choice= sc.nextInt();
         switch(choice){
             case 1:System.out.println("Running"); break;
             case 2: break;
             case 3: break;
             case 4: break;
             case 5: break;
             case 6: break;
             case 7: break;
             case 8: break;
             case 9: System.out.println("Program exiting..."); break;
    
         }
        }while(choice>9||choice<=8);
       
       
       }
    }
}
