/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

import java.util.regex.Pattern;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public interface Acceptable {

    public final String PHONE_PATTERN = "^0\\d{9}$";
    public final String EMAIL_PATTERN = "^[\\w.%+-]+@[\\w.-]+\\.[a-zA-Z]{2,6}$";
    public final String NAME_PATTERN = "^.{2,25}$";
    public final String CUSTOMER_CODE_PATTERN = "^[CcGgKk]\\d{4}$";
    public final String VIETTEL_PATTERN = "^(032|033|034|035|036|037|038|039|086|096|097|098)\\d{7}$";
    public final String VNPT_PATTERN = "^(081|082|083|084|085|088|091|094)\\d{7}$";
    public final String MOBILE_PATTERN = "^(090|093|089|070|079|077|076|078)\\d{7}$";
    public final String MENU_PATTERN = "^[Pp][Ww]\\d{3}$";
    public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    static boolean isValidDate(String date) {
        try {
           LocalDate praseDate= LocalDate.parse(date, FORMATTER);
            return praseDate.isAfter(LocalDate.now());
        } catch (DateTimeParseException e) {
            return false;
        }

    }

    static boolean isValid(String data, String pattern) {

        return Pattern.matches(pattern, data);
    }
}
