/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

import java.util.Scanner;

public class Inputter {

    private static final Scanner sc = new Scanner(System.in);

    public static int getInt(String mess) {
        while (true) {
            try {
                System.out.print(mess);
                return Integer.parseInt(sc.nextLine().trim());

            } catch (NumberFormatException e) {
                System.out.println("Dữ liệu không hợp lệ. Vui lòng nhập số nguyên!");
            }

        }

    }

    public static String getString(String mess, String pattern) {
        while (true) {
            System.out.println(mess);
            String input = sc.nextLine().trim();
            if (Acceptable.isValid(input, pattern)) {
                return input;
            }
            System.out.println("Dữ liệu không hợp lệ vui lòng nhập lại!");
        }

    }

    public static double getDouble(String mess) {
        while (true) {
            try {
                System.out.println(mess);
                return Double.parseDouble(sc.nextLine().trim());

            } catch (NumberFormatException e) {
                System.out.println("Dữ liệu không hợp lệ. Vui lòng nhập só thực");

            }

        }
    }

    public static String getCode(String mess, String pattern) {
        while (true) {
            System.out.println(mess);
            String input = sc.nextLine().trim();
            if (Acceptable.isValid(input, pattern)) {
                return input.substring(0, 1).toUpperCase() + input.substring(1);
            }
            System.out.println("Code not invalid!!!Please enter again...");

        }

    }

    public static String getMenuCode(String mess, String pattern) {
        while (true) {
            System.out.println(mess);
            String input = sc.nextLine().trim();
            if (Acceptable.isValid(input, pattern)) {

                return input.substring(0, 2).toUpperCase() + input.substring(2);

            }
            System.out.println("Dữ liệu không hợp lệ. Vui lòng nhập lại!");
        }
    }

    public static String getDate(String mess) {
        while (true) {
            System.out.println(mess);
            String input = sc.nextLine().trim();
            if (Acceptable.isValidDate(input)) {
                return input;
            }
            System.out.println("Date is invalid!! Please enter again...");
        }

    }

    public static String formatName(String name) {
        int lastSpace = name.lastIndexOf(" ");
        if (lastSpace == -1) {
            return name;
        }
        String lastName = name.substring(lastSpace+1);
        String FirstAndMiddle = name.substring(0, lastSpace);
        return lastName+", "+FirstAndMiddle;
    }

    public static String inputAndLoop(String mess, String pattern) {
        return getString(mess, pattern);
    }
}
