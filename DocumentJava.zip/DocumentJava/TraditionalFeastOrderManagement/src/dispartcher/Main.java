/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dispartcher;

import tools.Inputter;
import java.util.Scanner;
import tools.Acceptable;
import business.CustomerList;
import model.Customer;
import business.FeastMenuManager;
import java.util.List;
import model.FeastMenu;
import business.FeastOrderList;
import model.FeastOrder;

public class Main {

    public static void main(String[] args) {
        CustomerList customerManager = new CustomerList();
        FeastOrderList orderManager = new FeastOrderList();
        FeastMenuManager menuManager = new FeastMenuManager();
        String dataCustomer = "src\\business\\customer.dat";
        String dataOrder = "src\\business\\order.dat";
        try {
            customerManager.loadFromFile(dataCustomer);
        } catch (Exception e) {
            System.out.println("Error loading customer data: " + e.getMessage());
        }
        try {
            orderManager.loadFromFile(dataOrder);
        } catch (Exception e) {
            System.out.println("Error loading order data: " + e.getMessage());
        }
        String choice;
        boolean run = true;
        while (run) {
            try {
                Menu();
                choice = Inputter.getString("Enter your choice: ", "^.*$");
                int c = Integer.parseInt(choice);
                switch (c) {

                    case 1:
                        addCustomer(customerManager);
                        break;
                    case 2:
                        updateCustomer(customerManager);
                        break;
                    case 3:
                        searchByName(customerManager);
                        break;
                    case 4:
                        display();
                        break;
                    case 5:
                        Order(customerManager, orderManager, menuManager);
                        break;
                    case 6:
                        UpdateOrder(customerManager, orderManager, menuManager);
                        break;
                    case 7:
                        SaveDataFile(customerManager, dataCustomer, orderManager, dataOrder);
                        break;
                    case 8:
                        DisplayData(customerManager, orderManager);
                        break;
                    default:
                        System.out.println("The program end run. Bye Bye (^ v ^)!!!");
                        run = false;

                }
            } catch (NumberFormatException e) {
                System.out.println("The program end run. Bye Bye (^ v ^)!!!");
                run = false;
            }
        }

    }
//----------------------------------------------------------------------------------------------------------

    public static void Menu() {
        System.out.println("**********Traditional Feast Order Management**********");
        System.out.println("1. Register customers.");
        System.out.println("2. Update customer information by name.");
        System.out.println("3. Search for customer information by name.");
        System.out.println("4. Display feast menus.");
        System.out.println("5. Place a feast order.");
        System.out.println("6. Update order information.");
        System.out.println("7. Save data to file.");
        System.out.println("8. Display Customer or Order lists");
        System.out.println("Press any key to end program");
        System.out.println("*******************************************************");

    }

    private static void addCustomer(CustomerList customerManager) {
        while (true) {
            System.out.println("New registration: ");
            String code;
            while (true) {
                code = Inputter.getCode("Enter customer code(kí tự đầu bắt đầu từ C, G, K ) e.g(C****): ", Acceptable.CUSTOMER_CODE_PATTERN);
                if (!customerManager.isCustomerCodeExist(code)) {
                    break;
                }
                System.out.println("The code has been existed!");
                return;
            }
            String name = Inputter.getString("Enter your name: ", Acceptable.NAME_PATTERN);
            String phone;
            while (true) {
                phone = Inputter.getString("Nhập số điện thoại: ", Acceptable.PHONE_PATTERN);
                if (Acceptable.isValid(phone, Acceptable.VIETTEL_PATTERN) || Acceptable.isValid(phone, Acceptable.MOBILE_PATTERN) || Acceptable.isValid(phone, Acceptable.VNPT_PATTERN)) {
                    break;
                }
                System.out.println("The phone invalid! Please enter again!!!");

            }
            String email = Inputter.getString("Enter email: ", Acceptable.EMAIL_PATTERN);
            Customer customer = new Customer(code, name, phone, email);
            customerManager.addCustomer(customer);
            String enter = Inputter.getString("Are you want continue to add customer(Y/N)??", "^[YyNn]$");

            if (enter.equalsIgnoreCase("N")) {
                System.out.println("Customer registered successfully.");
                break;
            }
        }
    }

    private static void updateCustomer(CustomerList customerManager) {
        System.out.println("\n***Update Registration Information***");
        while (true) {
            String code = Inputter.getCode("Enter customer code: ", Acceptable.CUSTOMER_CODE_PATTERN);
            List<Customer> customers = customerManager.searchByCode(code);

            if (customers.isEmpty()) {
                System.out.println("This customer has not yet (T_T)");
                return;
            } else {
                Customer customer = customers.get(0);
                String header = String.format("| %-10s | %-20s | %-15s | %-30s |", "Code", "Name", "Phone number", "Email");
                String line = "+------------+----------------------+-----------------+--------------------------------+";
                System.out.println("-------Customer List-------");
                System.out.println(line);
                System.out.println(header);
                System.out.println(line);
                System.out.printf("| %-10s | %-20s | %-15s | %-30s |\n",
                        customer.getCode(),
                        Inputter.formatName(customer.getName()),
                        customer.getPhoneNumber(),
                        customer.getEmail());
                System.out.println(line);
                String confirmation = Inputter.getString("Are you sure you want to update this registration??(Y/N)", "^[YyNn]$");
                if (confirmation.equalsIgnoreCase("N")) {
                    System.out.println("The update has been canceled");
                    return;
                } else {
                    String name = Inputter.getString("Enter new name: ", "^.*$");
                    String phone;
                    while (true) {
                        phone = Inputter.getString("Enter new phone number: ", "^.*$");;
                        if (Acceptable.isValid(phone, Acceptable.VIETTEL_PATTERN) || Acceptable.isValid(phone, Acceptable.MOBILE_PATTERN) || Acceptable.isValid(phone, Acceptable.VNPT_PATTERN) || Acceptable.isValid(phone, "^.*$")) {
                            break;
                        }
                        System.out.println("The phone invalid! Please enter again!!!");

                    }

                    String email = Inputter.getString("Enter new email: ", "^.*$");
                    customerManager.updateCustomer(code, name, phone, email);
                    System.out.println("The customer information is updated successfully.");
                    return;

                }
            }

        }

    }

    private static void searchByName(CustomerList customerManage) {
        System.out.println("\n---Search information by name---");
        String name = Inputter.getString("Enter the name to search", ".*");
        customerManage.searchByName(name);

    }

    private static void display() {
        String filename = "src\\business\\FeastMenu.csv";
        List<FeastMenu> menuList = FeastMenuManager.readFeastMenusFromCSV(filename);
        FeastMenuManager.sortByPrice(menuList);
        FeastMenuManager.displayFeastenus(menuList);

    }

    private static void Order(CustomerList customerManager, FeastOrderList orderManager, FeastMenuManager menu) {
        System.out.println("---------Place a feast order-------");
        while (true) {
            String code = Inputter.getCode("Nhập code người dùng: ", Acceptable.CUSTOMER_CODE_PATTERN);
            if (!customerManager.isCustomerCodeExist(code)) {
                System.out.println("The customer has not yet (T_T)");
                String choice = Inputter.getString("Are you want enter code again to place(Y/N)??", "^[YyNn]$");
                if (choice.equalsIgnoreCase("N")) {
                    return;
                }
            } else {
                String codeMenu;
                while (true) {
                    codeMenu = Inputter.getMenuCode("Enter menu code(PW***):", Acceptable.MENU_PATTERN);
                    if (!menu.isValidMenuCode(codeMenu)) {
                        String choice = Inputter.getString("menu code has not yet are you want to enter again(Y/N)?? (> x <)", "^[YyNn]$");
                        if (choice.equalsIgnoreCase("N")) {
                            return;
                        }

                    } else {
                        break;
                    }
                }
                int numberOfTable;
                while (true) {
                    numberOfTable = Inputter.getInt("Enter number of table: ");
                    if (numberOfTable > 0) {
                        break;
                    }
                    System.out.println("Number of table must be larger than zero!!!");
                }
                String date = Inputter.getDate("Enter the event date(dd/MM/yyyy): ");
                List<FeastMenu> show2 = menu.searchByCode(codeMenu);
                FeastMenu feastmenu = show2.get(0);
                int price = menu.getPriceOfMenu(codeMenu);
                int totalCost = menu.getPriceOfMenu(codeMenu) * numberOfTable;
                FeastOrder feastorder = new FeastOrder(code, codeMenu, numberOfTable, date, totalCost, price);
                orderManager.add(feastorder);
                List<Customer> show1 = customerManager.searchByCode(code);
                Customer c = show1.get(0);
                List<FeastOrder> show = orderManager.searchByOrderId(feastorder.getOrderId());
                FeastOrder Order = show.get(0);

                System.out.println("--------------Customer order infomation------------------");
                System.out.println("-------[Order ID:" + feastorder.getOrderId() + "]------------");
                System.out.println("---------------------------------------------------------");
                System.out.println("Code             :" + code);
                System.out.println("Name             :" + Inputter.formatName(c.getName()));
                System.out.println("Phone number     :" + c.getPhoneNumber());
                System.out.println("Email            :" + c.getEmail());
                System.out.println("---------------------------------------------------------");
                System.out.println("Code of Set Menu :" + Order.getCodeOfSetMenu());
                System.out.println("Event Date       :" + Order.getDate());
                System.out.println("Number of tables :" + Order.getNumberOfTable());
                System.out.printf("Price            :%,d Vnd\n", feastmenu.getPrice());
                System.out.println("Ingredients      :" + feastmenu.getIngredients());
                System.out.println("---------------------------------------------------------");
                System.out.printf("Total cost       :%,d Vnd\n", Order.getTotalCost());
                System.out.println("---------------------------------------------------------");
                String enter = Inputter.getString("Bạn có muốn nhập thêm không(Y/N)??", "^[YyNn]$");

                if (enter.equalsIgnoreCase("N")) {
                    System.out.println("Customer registered successfully.");
                    break;
                }
            }

        }

    }

    private static void UpdateOrder(CustomerList customers, FeastOrderList orderManage, FeastMenuManager menu) {
        System.out.println("--------Update order information--------");
        while (true) {
            try {
                String orderId = Inputter.getString("Enter order id: ", "^.*$");
                int id = Integer.parseInt(orderId);
                List<FeastOrder> orders = orderManage.searchByOrderId(id);
                if (orders.isEmpty()) {
                    System.out.println("This order not exist!!!");
                    return;
                } else {
                    FeastOrder order = orders.get(0);
                    String header = String.format("| %-10s | %-15s | %-11s | %-15s | %-12s | %-10s | %-15s |", "ID", "Event Date", "Customer ID", "Set Menu", "Price", "Table", "Cost");
                    String line = "+------------+-----------------+-------------+-----------------+--------------+------------+-----------------+";
                    System.out.println("-------Order List-------");
                    System.out.println(line);
                    System.out.println(header);
                    System.out.println(line);
                    System.out.printf("| %-10d | %-15s | %-11s | %-15s | %-,12d | %-10d | %-,15d |\n",
                            order.getOrderId(),
                            order.getDate(),
                            order.getCodeCustomer(),
                            order.getCodeOfSetMenu(),
                            order.getPrice(),
                            order.getNumberOfTable(),
                            order.getTotalCost()
                    );
                    System.out.println(line);
                    String confirmation = Inputter.getString("Are you sure you want to update this registration??(Y/N)", "^[YyNn]$");
                    if (confirmation.equalsIgnoreCase("N")) {
                        System.out.println("The update has been canceled");
                        return;
                    } else {
                        String codeMenu;
                        int price = 0;
                        while (true) {
                            codeMenu = Inputter.getString("Enter menu code(PW***):", "^.*$");

                            if (menu.isValidMenuCode(codeMenu) || Acceptable.isValid(codeMenu, "^.*$")) {
                                if (menu.isValidMenuCode(codeMenu)) {
                                    price = menu.getPriceOfMenu(codeMenu);
                                    break;
                                }
                                break;
                            }
                            System.out.println("Please enter again!!!");

                        }
                        String date;
                        while (true) {
                            date = Inputter.getString("Enter new date(dd/MM/yyyy): ", "^.*$");
                            if (Acceptable.isValidDate(date) || Acceptable.isValid(date, "^.*$")) {
                                break;
                            }
                            System.out.println("Please enter again!!!");
                        }
                        String numberOftable;
                        int num = 0;
                        int totalCost = 0;
                        while (true) {
                            try {
                                numberOftable = Inputter.getString("Enter the number of table", "^.*$");
                                num = Integer.parseInt(numberOftable);
                                totalCost = num * price;
                                if (num > 0) {
                                    break;
                                }
                                System.out.println("The number of table must be larger than 0!!!");
                            } catch (NumberFormatException e) {
                                break;
                            }

                        }
                        orderManage.updateOrder(id, codeMenu, num, date, totalCost, price);
                        System.out.println("Update information successfully");
                        String enter = Inputter.getString("Are you want to continue  update order(Y/N)??", "^[YyNn]$");
                        if (enter.equalsIgnoreCase("N")) {
                            System.out.println("Customer registered successfully.");
                            break;
                        }

                    }

                }
            } catch (NumberFormatException e) {
                return;
            }

        }

    }

    private static void SaveDataFile(CustomerList customerManage, String customerData, FeastOrderList orderManage, String orderData) {
        System.out.println("\n---Save Data to File---");
        customerManage.saveToFile(customerData);
        orderManage.saveToFile(orderData);
    }

    private static void DisplayData(CustomerList customerManager, FeastOrderList orderManager) {
        boolean run = true;
        String choice;
        while (run) {

            try {
                MiniMenu();
                choice = Inputter.getString("Enter your choice: ", "^.*$");
                int c = Integer.parseInt(choice);
                switch (c) {
                    case 1:
                        customerManager.displayAll();
                        break;
                    case 2:
                        orderManager.displayAll();
                        break;
                    default:
                        return;
                }
            } catch (NumberFormatException e) {
                run = false;
            }
        }

    }

    private static void MiniMenu() {
        System.out.println("---Display Information---");
        System.out.println("1.Display customers data");
        System.out.println("2.Display orders data");
        System.out.println("Press any key to exit");
        System.out.println("-------------------------");

    }

}
