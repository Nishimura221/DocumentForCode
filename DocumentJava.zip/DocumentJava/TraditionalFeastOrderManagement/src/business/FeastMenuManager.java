/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import model.FeastMenu;

public class FeastMenuManager {

    private List<FeastMenu> menuList;

    public FeastMenuManager() {
        this.menuList = new ArrayList<>();
    }

    public static List<FeastMenu> readFeastMenusFromCSV(String filename) {
        List<FeastMenu> menuList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            boolean firstLine = true;
            while ((line = br.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                }
                String[] data = line.split(",", 4);
                if (data.length == 4) {
                    String code = data[0].trim();
                    String name = data[1].trim();
                    int price = Integer.parseInt(data[2].trim());
                    String ingredients = data[3].trim().replace("+", "\n+");
                    menuList.add(new FeastMenu(code, name, price, ingredients));
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error reading file: " + e.getMessage());

        } catch (NumberFormatException | IOException e) {

            System.out.println("Error in file csv!!!");
        }
        return menuList;

    }

    public static void sortByPrice(List<FeastMenu> menuList) {

        menuList.sort(Comparator.comparingInt(menu -> menu.getPrice()));

    }

    public static void displayFeastenus(List<FeastMenu> menuList) {
        if (menuList.isEmpty()) {
            System.out.println("Ko co data de hien thi");
            return;
        }
        System.out.println("-----Menu------");
        for (FeastMenu menu : menuList) {
            menu.display();

        }

    }
    

    public boolean isValidMenuCode(String code) {
        List<FeastMenu> menus = readFeastMenusFromCSV("src//business//FeastMenu.csv");
        for (FeastMenu menu : menus) {
            if (menu.getCode().equalsIgnoreCase(code)) {
                return true;

            }
        }
        return false;

    }

    public int getPriceOfMenu(String MenuCode) {
       List<FeastMenu> menus = readFeastMenusFromCSV("src//business//FeastMenu.csv");
        if (!isValidMenuCode(MenuCode)) {
            System.out.println("Code has not avaliable!!!");
        }
        for (FeastMenu feastmenu : menus) {
            if (feastmenu.getCode().equalsIgnoreCase(MenuCode)) {
                return feastmenu.getPrice();
            }

        }
        return 0;
    }
        public List<FeastMenu> searchByCode(String code) {
        List<FeastMenu> menus =readFeastMenusFromCSV("src//business//FeastMenu.csv");
        List<FeastMenu> result = new ArrayList<>();
        for (FeastMenu menu : menus) {
            if (menu.getCode().equalsIgnoreCase(code)) {
                result.add(menu);
            }
        }
        return result;
    }
}
