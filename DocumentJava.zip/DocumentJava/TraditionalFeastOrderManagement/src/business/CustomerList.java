/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import model.Customer;
import java.util.List;
import java.util.ArrayList;
import java.io.*;
import java.util.Collections;
import java.util.Comparator;
import tools.Acceptable;
import tools.Inputter;

public class CustomerList {

    List<Customer> customers;

    public CustomerList() {
        this.customers = new ArrayList<>();
    }

    public boolean isCustomerCodeExist(String code) {
        for (Customer c : customers) {
            if (c.getCode().equalsIgnoreCase(code)) {
                return true;
            }
        }
        return false;
    }

    public boolean addCustomer(Customer customer) {

        customers.add(customer);
        return true;

    }

    public boolean updateCustomer(String code, String name, String phone, String email) {
        for (Customer customer : customers) {
            if (customer.getCode().equalsIgnoreCase(code)) {
                if (!name.isEmpty()) {
                    customer.setName(name);
                }
                if (!phone.isEmpty() && Acceptable.isValid(phone, Acceptable.PHONE_PATTERN)) {
                    customer.setPhoneNumber(phone);
                }
                if (!email.isEmpty() && Acceptable.isValid(email, Acceptable.EMAIL_PATTERN)) {
                    customer.setEmail(email);
                }
                return true;
            }
        }
        return false;
    }

    public List<Customer> searchByCode(String code) {
        List<Customer> result = new ArrayList<>();
        for (Customer customer : customers) {
            if (customer.getCode().equalsIgnoreCase(code)) {
                result.add(customer);
            }
        }
        return result;
    }

    public void searchByName(String name) {
        List<Customer> result = new ArrayList<>();
        for (Customer customer : customers) {
            if (customer.getName().toLowerCase().contains(name.toLowerCase())) {
                result.add(customer);
            }

        }
        if (result.isEmpty()) {
            System.out.println("No one matches the search criteria!");

        } else {
            System.out.println("Những người được tìm thấy theo kí tự được nhập");
            String header = String.format("| %-10s | %-20s | %-15s | %-30s |", "Code", "Name", "PhoneNumber", "Email");
            String line = "+------------+----------------------+-----------------+--------------------------------+";
            System.out.println(line);
            System.out.println(header);
            System.out.println(line);
            for (Customer customer : result) {
                System.out.printf("| %-10s | %-20s | %-15s | %-30s |\n", customer.getCode(), customer.getName(), customer.getPhoneNumber(), customer.getEmail());

            }
            System.out.println(line);
        }
    }

    public void sortByName(List<Customer> customer) {
        Collections.sort(customer, Comparator.comparing(c -> {
        String[] parts = c.getName().trim().split("\\s+");
        return parts[parts.length - 1]; // Sắp xếp theo tên cuối cùng
    }, String.CASE_INSENSITIVE_ORDER));
    }

    public void displayAll() {
        CustomerList list = new CustomerList();
        list.sortByName(customers);
        if (customers.isEmpty()) {
            System.out.println("No data in system");
        } else {
            String header = String.format("| %-10s | %-20s | %-15s | %-30s |", "Code", "Name", "Phone number", "Email");
            String line = "+------------+----------------------+-----------------+--------------------------------+";
            System.out.println("-------Customer List-------");
            System.out.println(line);
            System.out.println(header);
            System.out.println(line);
            for (Customer customer : customers) {
                System.out.printf("| %-10s | %-20s | %-15s | %-30s |\n",
                        customer.getCode(),
                        Inputter.formatName(customer.getName()),
                        customer.getPhoneNumber(),
                        customer.getEmail());
            }
            System.out.println(line);

        }

    }

    public void saveToFile(String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(customers);
            System.out.println("Data has been saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving data" + e.getMessage());

        }

    }

    public void loadFromFile(String filename) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            customers = (List<Customer>) ois.readObject();
            System.out.println("Customer's data has been loaded successfully.");
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filename);
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found: " + e.getMessage());
        }
    }

}
