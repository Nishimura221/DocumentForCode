/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.ArrayList;
import java.util.List;
import model.FeastOrder;
import java.io.*;
import model.Customer;
import business.FeastMenuManager;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Comparator;
import model.FeastMenu;
import tools.Acceptable;

public class FeastOrderList {

    List<FeastOrder> manageOrder;

    public FeastOrderList() {
        this.manageOrder = new ArrayList<>();
    }

    public boolean add(FeastOrder orders) {
        orders.setOrderId(manageOrder.size() + 1);
        manageOrder.add(orders);

        return true;
    }

    public boolean isOrderIdExist(int code) {
        for (FeastOrder o : manageOrder) {
            if (o.getOrderId() == code) {
                return true;
            }
        }
        return false;
    }

    public List<FeastOrder> searchByOrderId(int id) {
        List<FeastOrder> result = new ArrayList<>();
        for (FeastOrder feastorder : manageOrder) {
            if (feastorder.getOrderId() == id) {
                result.add(feastorder);
            }
        }
        return result;
    }

    public boolean updateOrder(int id, String codeOfSetMenu, int numberOfTable, String date, int totalCost, int price) {
        FeastMenuManager menu = new FeastMenuManager();
        for (FeastOrder order : manageOrder) {
            if (order.getOrderId() == id) {

                if (!codeOfSetMenu.isEmpty() && menu.isValidMenuCode(codeOfSetMenu)) {
                    order.setCodeOfSetMenu(codeOfSetMenu);
                }
                if (numberOfTable != 0) {
                    order.setNumberOfTable(numberOfTable);
                }
                if (!date.isEmpty() && Acceptable.isValidDate(date)) {
                    order.setDate(date);
                }
                if (totalCost != 0) {
                    order.setTotalCost(totalCost);
                }
                if (price != 0) {
                    order.setPrice(price);
                }

                return true;
            }

        }
        return false;
    }

    public void saveToFile(String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(manageOrder);
            System.out.println("Data has been saved successfully");

        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());

        }
    }


    public static void sortByDate(List<FeastOrder> orders) {
        Collections.sort(orders, Comparator.comparing(order -> LocalDate.parse(order.getDate(), Acceptable.FORMATTER)));

    }

    public void displayAll() {
        FeastOrderList list = new FeastOrderList();
        list.sortByDate(manageOrder);
        if (manageOrder.isEmpty()) {
            System.out.println("No data in system");
        } else {
            String header = String.format("| %-10s | %-15s | %-11s | %-15s | %-12s | %-10s | %-15s |", "ID", "Event Date", "Customer ID", "Set Menu", "Price", "Table", "Cost");
            String line = "+------------+-----------------+-------------+-----------------+--------------+------------+-----------------+";
            System.out.println("-------Order List-------");
            System.out.println(line);
            System.out.println(header);
            System.out.println(line);
            for (FeastOrder order : manageOrder) {
                System.out.printf("| %-10d | %-15s | %-11s | %-15s | %-,12d | %-10d | %-,15d |\n",
                        order.getOrderId(),
                        order.getDate(),
                        order.getCodeCustomer(),
                        order.getCodeOfSetMenu(),
                        order.getPrice(),
                        order.getNumberOfTable(),
                        order.getTotalCost()
                );
                System.out.println(line);

            }
        }

    }

    public void loadFromFile(String filename) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            manageOrder = (List<FeastOrder>) ois.readObject();
            System.out.println("Order's data has been loaded successfully");

        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filename);
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found: " + e.getMessage());
        }

    }

}
