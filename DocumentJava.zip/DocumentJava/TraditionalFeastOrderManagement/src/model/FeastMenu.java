/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author DELL
 */
public class FeastMenu {

    private String code;
    private String name;
    private int price;
    private String ingredients;

    public FeastMenu(String code, String name, int price, String ingredients) {
        this.code = code;
        this.name = name;
        this.price = price;
        this.ingredients = ingredients;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }



    public String getIngredients() {
        return ingredients;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

   
  public void display() {
        System.out.println("------------------------------------------------");
        System.out.println("Code       : " + code);
        System.out.println("Name       : " + name);
        System.out.printf("Price       : %,d Vnd\n",getPrice());
        System.out.println("Ingredients: " + ingredients);
        System.out.println("------------------------------------------------");
    }
}
