/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author DELL
 */
public class FeastOrder implements Serializable {
    private int OrderId;
    private String codeCustomer;
    private String codeOfSetMenu;
    private int numberOfTable;
    private String date;
    private int totalCost;
    private int price;

    public FeastOrder() {
    }

    public FeastOrder(String codeCustomer, String codeOfSetMenu, int numberOfTable, String date, int totalCost, int price) {
        this.codeCustomer = codeCustomer;
        this.codeOfSetMenu = codeOfSetMenu;
        this.numberOfTable = numberOfTable;
        this.date = date;
        this.totalCost = totalCost;
        this.price = price;
    }

    public FeastOrder(int OrderId, String codeCustomer, String codeOfSetMenu, int numberOfTable, String date, int totalCost, int price) {
        this.OrderId = OrderId;
        this.codeCustomer = codeCustomer;
        this.codeOfSetMenu = codeOfSetMenu;
        this.numberOfTable = numberOfTable;
        this.date = date;
        this.totalCost = totalCost;
        this.price = price;
    }

    public FeastOrder(int OrderId, String codeOfSetMenu, int numberOfTable, String date, int totalCost, int price) {
        this.OrderId = OrderId;
        this.codeOfSetMenu = codeOfSetMenu;
        this.numberOfTable = numberOfTable;
        this.date = date;
        this.totalCost = totalCost;
        this.price = price;
    }

  
    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(int totalCost) {
        this.totalCost = totalCost;
    }



 

    public int getOrderId() {
        return OrderId;
    }

    public void setOrderId(int OrderId) {
        this.OrderId = OrderId;
    }

    

    public String getCodeCustomer() {
        return codeCustomer;
    }

    public void setCodeCustomer(String codeCustomer) {
        this.codeCustomer = codeCustomer;
    }

    public String getCodeOfSetMenu() {
        return codeOfSetMenu;
    }

    public void setCodeOfSetMenu(String codeOfSetMenu) {
        this.codeOfSetMenu = codeOfSetMenu;
    }

    public int getNumberOfTable() {
        return numberOfTable;
    }

    public void setNumberOfTable(int numberOfTable) {
        this.numberOfTable = numberOfTable;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    
}
