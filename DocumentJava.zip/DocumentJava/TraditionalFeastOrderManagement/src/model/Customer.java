/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author DELL
 */
public class Customer implements Serializable {
    private String code;
    private String name;
    private String PhoneNumber;
    private String Email;

    public Customer() {
    }

    public Customer(String code, String name, String PhoneNumber, String Email) {
        this.code = code;
        this.name = name;
        this.PhoneNumber = PhoneNumber;
        this.Email = Email;
    }

   

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    @Override
    public String toString() {
        return String.format(getCode()+", "+getName()+", "+getPhoneNumber()+", "+getEmail());
    }
    
    
    
}
